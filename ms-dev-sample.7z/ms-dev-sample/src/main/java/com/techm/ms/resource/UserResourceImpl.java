package com.techm.ms.resource;

import java.util.List;

import javax.ws.rs.core.Link;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.util.UriComponentsBuilder;

import com.techm.ms.exception.CustomError;
import com.techm.ms.model.Account;
import com.techm.ms.model.User;
import com.techm.ms.model.representation.Resource;
import com.techm.ms.model.representation.ResourceCollection;
import com.techm.ms.service.UserService;

@Controller
public class UserResourceImpl implements UserResource {
	
    @Autowired
    UserService userService;
	
	
    private static String baseUrl = "/users";
    
    
    public ResponseEntity<?> createUser(@RequestBody User user, UriComponentsBuilder ucBuilder) {
      //  logger.info("Creating User : {}", user);
 
        if (userService.isUserExist(user)) {
           // logger.error("Unable to create. A User with name {} already exist", user.getName());
            return new ResponseEntity("Unable to create. A User with name " + 
            user.getName() + " already exist.",HttpStatus.CONFLICT);
        }
        userService.saveUser(user);
 
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/api/user/{id}").buildAndExpand(user.getId()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }
 
	
	
    
    
    public ResponseEntity<?> getUser(@PathVariable("id") long id) {
       // logger.info("Fetching User with id {}", id);
        User user = userService.findById(id);
        if (user == null) {
           // logger.error("User with id {} not found.", id);
            return new ResponseEntity(new CustomError("User with id " + id 
                    + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<User>(user, HttpStatus.OK);
    }
    
}
