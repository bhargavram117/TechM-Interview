package com.techm.ms.exception;

public class CustomError {

    private String errorMessage;
    
   

    
	

    






	public CustomError(String errorMessage2) {
		
		// TODO Auto-generated constructor stub
		this.errorMessage=errorMessage2;
	}






	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}






	public String getErrorMessage() {
        return errorMessage;
    }

}
