package com.techm.ms.service;

import com.techm.ms.model.User;

public interface UserService {
	void saveUser(User user);
	boolean isUserExist(User user);
	 User findById(long id);
    

}
