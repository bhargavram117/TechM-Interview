# automation-test-engineer-sample
Interview sample Project

1) Run maven clean install
2) Run the application as Spring boot
3) Access the Swagger document for the API docs (http://localhost:8080/index.html)
4) There is one Component and one integration test present for Account Service in the project for sample reference.
5) Review if Account Service all scenerios are covered. If not include the missing test cases.
6) Add all the test cases for User service.

