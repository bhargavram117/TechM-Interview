package com.techm.ms.resource;

/**
 * This is the Interface definition for User Resource
 * 
 */
public interface UserResource {
	
}