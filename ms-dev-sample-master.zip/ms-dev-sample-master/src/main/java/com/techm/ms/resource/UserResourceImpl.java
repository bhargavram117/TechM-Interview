package com.techm.ms.resource;

import org.springframework.stereotype.Controller;

@Controller
public class UserResourceImpl implements UserResource {
	
}
