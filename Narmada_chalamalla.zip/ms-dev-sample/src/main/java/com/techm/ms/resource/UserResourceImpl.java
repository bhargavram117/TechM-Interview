package com.techm.ms.resource;

import java.net.URI;
import java.util.List;

import javax.ws.rs.core.Link;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.techm.ms.service.UserService;
import com.techm.ms.model.User;

@Controller
public class UserResourceImpl implements UserResource {
	
	public static final Logger logger = LoggerFactory.getLogger(UserResourceImpl.class);

	@Autowired
	UserService userService; //Service which will do all data retrieval/manipulation work
		
	private static String baseUrl = "/users";
	
	
		@Override
		public Response getUser(long userId ){
			System.out.println("inside getuser "+ userId);
			logger.debug("userId"+userId);
		User user = userService.findById(userId);		
		if (user == null) {
			//return Response.noContent().build();
			return Response.status(404).build();
		}		
		Link link = Link.fromUri(baseUrl).rel("self").build();		
		//ResourceCollection<Account> resource = new ResourceCollection<>(accounts);
		return Response.ok(user).links(link).build();

	}

	@Override
	public Response createUser(User user){
		boolean success = userService.createUser(user);		
		if (!success) {
			return Response.status(409).build();
		}		
		Link link = Link.fromUri(baseUrl).rel("self").build();		
				return Response.status(201).build();
	}	

	
	
}
