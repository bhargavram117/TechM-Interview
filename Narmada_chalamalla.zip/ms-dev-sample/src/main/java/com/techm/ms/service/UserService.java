package com.techm.ms.service;

import com.techm.ms.model.User;

public interface UserService {
	
	public boolean createUser(User user) ;
	
	public User findById(long id);
	
	
	
	

}
