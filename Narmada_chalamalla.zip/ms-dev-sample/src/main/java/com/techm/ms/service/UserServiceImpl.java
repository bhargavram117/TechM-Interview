package com.techm.ms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.techm.ms.model.User;

@Service("userService")
public class UserServiceImpl implements UserService{
	
private static List<User> users;

	
	static {
		users= populateDummyUsers();
	}

	
	public User findById(long id) {
		System.out.println("inside findbyid "+ id);
		for(User user : users){
			if(user.getId() == id){
				return user;
			}
		}
		return null;
	}
	
	public boolean createUser(User user) {
		for(User existUser : users) {
			if(existUser.getId() == user.getId()){
				return false;
			}
			
			else {
				users.add(user);
			}
		}
			
		return true;
	}
	
	
	private static List<User> populateDummyUsers(){
		List<User> users = new ArrayList<User>();
//		users.add(new User(counter.incrementAndGet(),"Account1"));
//		users.add(new User(counter.incrementAndGet(),"Account2"));
//		users.add(new User(counter.incrementAndGet(),"Account3"));
		System.out.println("inside populate dummies");
		users.add(new User(1L,"User1",30, 111));
		users.add(new User(2L,"User2", 20, 111));
		users.add(new User(3L,"User3",20, 111));
		return users;
	}

}
